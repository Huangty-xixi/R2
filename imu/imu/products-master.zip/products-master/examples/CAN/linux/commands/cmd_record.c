#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <stdint.h>
#include <stdbool.h>
#include <errno.h>
#include "../can_interface.h"
#include "../log.h"
#include "../utils.h"
#include "../help.h"
#include "../config.h"
#include "../commands.h"
#include "hipnuc_can_common.h"
#include "hipnuc_j1939_parser.h"
#include "canopen_parser.h"

static volatile sig_atomic_t g_running = 1;

static void on_signal(int sig)
{
    (void)sig;
    g_running = 0;
}

int cmd_record(int argc, char *argv[])
{
    const char *out_path = NULL;
    uint8_t target_nodes[32];
    int target_count = config_get_target_nodes(target_nodes, 32);
    
    for (int i = 1; i < argc; ++i) {
        if ((strcmp(argv[i], "-o") == 0 || strcmp(argv[i], "--out") == 0) && i + 1 < argc) {
            out_path = argv[++i];
        } else {
            help_print_arg_error_json("stream record", "usage: stream record -o <file>");
            return CANHOST_EXIT_INVALID_ARGS;
        }
    }
    
    if (!out_path) {
        help_print_arg_error_json("stream record", "missing output file (-o FILE)");
        return CANHOST_EXIT_INVALID_ARGS;
    }
    if (target_count <= 0) {
        help_print_arg_error_json("stream record", "no target node configured");
        return CANHOST_EXIT_INVALID_ARGS;
    }

    const char *ifname = config_get_interface();
    int sockfd = can_open_socket(ifname);
    if (sockfd < 0) {
        help_print_can_setup(ifname);
        return CANHOST_EXIT_RUNTIME_ERROR;
    }

    FILE *file = fopen(out_path, "w");
    if (!file) {
        log_error("Failed to open %s: %s", out_path, strerror(errno));
        can_close_socket(sockfd);
        return CANHOST_EXIT_RUNTIME_ERROR;
    }
    
    // Set large buffer for file I/O
    setvbuf(file, NULL, _IOFBF, 1024 * 1024);

    signal(SIGINT, on_signal);
    signal(SIGTERM, on_signal);
    log_info("Recording JSON on %s -> %s", ifname, out_path);

    hipnuc_can_frame_t frames[256];
    size_t batch_cap = sizeof(frames) / sizeof(frames[0]);

    uint64_t rx_frames = 0;
    uint64_t dropped_frames = 0;
    uint64_t written_frames = 0;
    uint64_t last_print_rx = 0;
    uint32_t last_print_ms = utils_get_timestamp_ms();

    while (g_running) {
        int r = can_receive_frames(sockfd, frames, batch_cap, 100);

        if (r < 0) {
            log_error("Receive error");
            fclose(file);
            can_close_socket(sockfd);
            return CANHOST_EXIT_RUNTIME_ERROR;
        }

        if (r == 0) {
            uint32_t now_ms = utils_get_timestamp_ms();
            if (now_ms - last_print_ms >= 1000) {
                uint64_t delta_rx = rx_frames - last_print_rx;
                double fps = (double)delta_rx * 1000.0 / (double)(now_ms - last_print_ms);
                printf("\rrx=%llu written=%llu dropped=%llu fps=%.1f   ",
                       (unsigned long long)rx_frames,
                       (unsigned long long)written_frames,
                       (unsigned long long)dropped_frames,
                       fps);
                fflush(stdout);
                last_print_rx = rx_frames;
                last_print_ms = now_ms;
            }
            continue;
        }

        for (int i = 0; i < r; ++i) {
            can_sensor_data_t data;
            memset(&data, 0, sizeof(data));
            data.node_id = hipnuc_can_extract_node_id(frames[i].can_id);
            
            bool match = false;
            for (int k = 0; k < target_count; ++k) {
                if (data.node_id == target_nodes[k]) {
                    match = true;
                    break;
                }
            }
            if (!match) continue;

            data.hw_ts_us = frames[i].hw_ts_us;

            int msg_type = (frames[i].can_id & HIPNUC_CAN_EFF_FLAG)
                         ? hipnuc_j1939_parse_frame(&frames[i], &data)
                         : canopen_parse_frame(&frames[i], &data);

            if (msg_type == CAN_MSG_UNKNOWN || msg_type == CAN_MSG_ERROR) {
                dropped_frames++;
                continue;
            }

            can_json_output_t json;
            if (hipnuc_can_to_json(&data, msg_type, &json) > 0) {
                fwrite(json.buffer, 1, json.length, file);
                written_frames++;
            }
        }
        rx_frames += r;

        uint32_t now_ms = utils_get_timestamp_ms();
        if (now_ms - last_print_ms >= 1000) {
            uint64_t delta_rx = rx_frames - last_print_rx;
            double fps = (double)delta_rx * 1000.0 / (double)(now_ms - last_print_ms);
            printf("\rrx=%llu written=%llu dropped=%llu fps=%.1f   ",
                   (unsigned long long)rx_frames,
                   (unsigned long long)written_frames,
                   (unsigned long long)dropped_frames,
                   fps);
            fflush(stdout);
            last_print_rx = rx_frames;
            last_print_ms = now_ms;
        }
    }

    printf("\n");
    log_info("Recorded %llu frames (%llu dropped)",
             (unsigned long long)written_frames,
             (unsigned long long)dropped_frames);

    fflush(file);
    fclose(file);
    can_close_socket(sockfd);
    return CANHOST_EXIT_OK;
}
